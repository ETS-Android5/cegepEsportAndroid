package net.info420.photos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    //propriétés
    private ImageView imgPhoto;
    private Button btnPhoto;
    private TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initActivity();
    }

    /*
    Initialisations
     */
    private void initActivity(){
        //lien avec les objets graphiques
        imgPhoto = (ImageView) findViewById(R.id.imgPhoto);
        btnPhoto = (Button) findViewById(R.id.btnPhoto);
        //textView = (TextView) findViewById(R.id.textView);
        //Initialisation méthode clic sur boutton
        createOnClicPhotoButton();

    }

    /**
     * evenement clic
     */
    private void createOnClicPhotoButton(){
        btnPhoto.setOnClickListener(new View.OnClickListener(){
            @Override

            public void onClick(View v) {
                //accès à la galerie du téléphone
                Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(galleryIntent, 1);
            }
        });
    }
    public void onActivityResult(int RequestCode, int resultCode, Intent data) {

        super.onActivityResult(RequestCode, resultCode, data);
        //vérifie si une image est récupérée
        if(RequestCode==1 && resultCode==RESULT_OK){ //resulteCode verifie si l'image a été sélectionée
            Uri selectedImage = data.getData();
            String[] filePathColum = {MediaStore.Images.Media.DATA};
            //Cuseur d'accès au chemin de l'image
            Cursor cursor = this.getContentResolver().query(selectedImage, filePathColum,null,null,null);
            //position sur la première ligne
            cursor.moveToFirst ();
            int columnIndex = cursor.getColumnIndex(filePathColum[0]);
            String imgPath = cursor.getString(columnIndex);
            cursor.close();

            //recuperation image
            Bitmap image = BitmapFactory.decodeFile((imgPath));

            //affiche
            imgPhoto.setImageBitmap(image);
        }else{
            Toast.makeText(this, "Aucune image sélectionnée", Toast.LENGTH_LONG).show();
        }
    }
}